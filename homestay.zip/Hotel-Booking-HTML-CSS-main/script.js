   // Track current slide for each carousel
   const currentSlides = {
    track1: 0,
    track2: 0,
    track3: 0
  };
  
  // Get number of slides for each track
  const slideCounts = {
    track1: document.getElementById('track1').children.length,
    track2: document.getElementById('track2').children.length,
    track3: document.getElementById('track3').children.length
  };
  
  function moveSlide(trackId, direction) {
    const track = document.getElementById(trackId);
    const navId = trackId.replace('track', 'nav');
    
    // Update current slide index
    currentSlides[trackId] = (currentSlides[trackId] + direction + slideCounts[trackId]) % slideCounts[trackId];
    
    // Update carousel position
    track.style.transform = `translateX(-${currentSlides[trackId] * 100}%)`;
    
    // Update dots
    updateDots(navId, currentSlides[trackId]);
  }
  
  function goToSlide(trackId, navId, slideIndex) {
    const track = document.getElementById(trackId);
    
    // Update current slide index
    currentSlides[trackId] = slideIndex;
    
    // Update carousel position
    track.style.transform = `translateX(-${slideIndex * 100}%)`;
    
    // Update dots
    updateDots(navId, slideIndex);
  }
  
  function updateDots(navId, activeIndex) {
    const dots = document.getElementById(navId).children;
    for (let i = 0; i < dots.length; i++) {
      dots[i].classList.toggle('active', i === activeIndex);
    }
  }